
import numpy as np
import pandas as pd
import seaborn as sns
sns.set_palette('husl')

import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.impute import SimpleImputer

# Step 1: Load Iris dataset
iris = load_iris()

data = pd.DataFrame(
    iris.data,
    columns=iris.feature_names
)

data['Species'] = iris.target

# Step 2: Display data before preprocessing
print("Data Before Preprocessing:")
print(data.head())

# Step 3: Check missing values
print("\nMissing Values Before Preprocessing:")
print(data.isnull().sum())

# Step 4: Select numerical columns
numeric_columns = data.select_dtypes(include=np.number).columns

# Step 5: Handle missing values using median
imputer = SimpleImputer(strategy='median')

data[numeric_columns] = imputer.fit_transform(
    data[numeric_columns]
)

# Step 6: Display data after preprocessing
print("\nData After Preprocessing:")
print(data.head())

# Step 7: Check missing values
print("\nMissing Values After Preprocessing:")
print(data.isnull().sum())

# Step 8: Dataset information
print("\nDataset Information:")
print(data.info())

# Step 9: Visualize missing values
plt.figure(figsize=(8, 4))
sns.heatmap(data.isnull(), cbar=False, cmap='viridis')

plt.title("Missing Values After Preprocessing")
plt.show()
