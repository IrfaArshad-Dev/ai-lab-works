
import numpy as np
import pandas as pd
import seaborn as sns
sns.set_palette('husl')

import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Step 1: Load Iris Dataset
iris = load_iris()

data = pd.DataFrame(
    iris.data,
    columns=iris.feature_names
)

data['Species'] = iris.target

print("Iris Dataset:")
print(data.head())

# Step 2: Separate Features and Label
X = data.drop('Species', axis=1)
y = data['Species']

# Step 3: Split Dataset into Training and Testing
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

print("\nTraining Data:", X_train.shape)
print("Testing Data:", X_test.shape)

# Step 4: Apply Feature Scaling
scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Step 5: Train KNN Model
model = KNeighborsClassifier(n_neighbors=5)

model.fit(X_train, y_train)

# Step 6: Make Predictions
y_pred = model.predict(X_test)

print("\nPredicted Values:")
print(y_pred)

print("\nActual Values:")
print(y_test.values)

# Step 7: Calculate Accuracy
accuracy = metrics.accuracy_score(y_test, y_pred)

print("\nModel Accuracy:")
print(accuracy)

# Step 8: Confusion Matrix
cm = metrics.confusion_matrix(y_test, y_pred)

print("\nConfusion Matrix:")
print(cm)

# Step 9: Display Confusion Matrix Graph
sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    cmap='Blues',
    xticklabels=iris.target_names,
    yticklabels=iris.target_names
)

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Iris Confusion Matrix")
plt.show()


