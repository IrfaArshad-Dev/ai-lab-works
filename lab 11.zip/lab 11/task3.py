
import numpy as np
import pandas as pd
import seaborn as sns
sns.set_palette('husl')

import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Step 1: Load Iris Dataset
iris = load_iris()

data = pd.DataFrame(
    iris.data,
    columns=iris.feature_names
)

data['Species'] = iris.target

# Step 2: Separate Features and Label
X = data.drop('Species', axis=1)
y = data['Species']

# Step 3: Split Dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

# Step 4: Train Simple Model (Low Depth)
simple_model = DecisionTreeClassifier(
    max_depth=1, random_state=42
)

simple_model.fit(X_train, y_train)

# Calculate Simple Model Accuracy
simple_train_accuracy = accuracy_score(
    y_train, simple_model.predict(X_train)
)

simple_test_accuracy = accuracy_score(
    y_test, simple_model.predict(X_test)
)

# Step 5: Train Complex Model (High Depth)
complex_model = DecisionTreeClassifier(
    max_depth=None, random_state=42
)

complex_model.fit(X_train, y_train)

# Calculate Complex Model Accuracy
complex_train_accuracy = accuracy_score(
    y_train, complex_model.predict(X_train)
)

complex_test_accuracy = accuracy_score(
    y_test, complex_model.predict(X_test)
)

# Step 6: Display Results
print("Simple Model (Low Depth)")
print("Training Accuracy:", simple_train_accuracy)
print("Testing Accuracy:", simple_test_accuracy)

print("\nComplex Model (High Depth)")
print("Training Accuracy:", complex_train_accuracy)
print("Testing Accuracy:", complex_test_accuracy)

# Step 7: Compare Results Using Graph
models = ['Simple Model', 'Complex Model']

training_accuracy = [
    simple_train_accuracy,
    complex_train_accuracy
]

testing_accuracy = [
    simple_test_accuracy,
    complex_test_accuracy
]

x = np.arange(len(models))
width = 0.35

plt.figure(figsize=(8, 5))

plt.bar(x - width/2, training_accuracy,
        width, label='Training Accuracy')

plt.bar(x + width/2, testing_accuracy,
        width, label='Testing Accuracy')

plt.xlabel('Models')
plt.ylabel('Accuracy')
plt.title('Overfitting vs Underfitting')
plt.xticks(x, models)
plt.legend()
plt.show()
